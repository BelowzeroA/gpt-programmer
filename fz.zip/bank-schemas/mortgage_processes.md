# Mortgage Process Domain Classification

The data structures in this repository primarily support **mortgage offer and deed execution**, **agreement administration**, and **collateral registration**. They do not represent a complete mortgage application or underwriting process.

| Domain area | Mortgage lifecycle classification | Typical data and use cases |
|---|---|---|
| `model/loans`, `dto/loans` | Mortgage agreement terms and execution-stage administration | Principal and balance, interest rates, fixed-rate periods, repayment schedules, construction depots, payment accounts, loan recalculation, and agreement mutations. |
| `model/client/active/loan`, `dto/client/active/loan` | Existing contracts being repaid or converted during mortgage execution | Existing mortgage and consumer-loan contracts, remaining principal, repayment amount, full-repayment indicators, compensation interest, and repayment on the deed-signing date. |
| `model/securities`, `dto/securities` | Collateral and legal-security registration and administration | Mortgages, registered properties, cadastral information, valuations, security ranking, prior mortgages, pledged insurance policies, beneficiaries, and NHG guarantees. |
| `model/supplement`, `dto/supplement` | Mortgage execution and settlement supplements | Notary details, settlement accounts, appraisal costs, guarantee costs, advice costs, intermediary details, insurance information, and old/new dossier values. |
| `model/client`, `dto/client` | Customer reference data | Client identity, address, contact information, relationship manager, customer segment, and active-client status. These structures do not model income or affordability assessment. |
| `model/institution`, `dto/institution` | External-party and institution reference data | Banks, insurers, notaries, institution roles, addresses, legal names, and payment-account details. |
| `dto/cops`, `model/copsdocumentgenerator`, `model/documentgeneratordetails` | Offer/deed and settlement document generation | Closing statements, insurance-payment documents, dossier documents, notary data, generated PDFs, and document-generation status or error handling. |
| Mortgage application/origination | Largely absent | No first-class application aggregate, applicant employment or income verification, affordability calculation, credit-bureau checks, underwriting decision, approval conditions, or application-document checklist. |
| Long-term mortgage servicing | Partially represented | Balances, rates, repayment data, and agreement changes are present, but broad servicing concepts such as arrears, collections, complaints, and annual statements are not modeled. |

## Overall classification

The most accurate description is:

> A shared domain library for administering mortgage loan agreements, collateral, and settlement/document workflows during the offer and deed-execution phase.

It is therefore a useful source for synthetic scenarios involving:

- mortgage agreement setup and recalculation;
- collateral registration and valuation;
- repayment or conversion of existing loans;
- notary and closing-statement preparation;
- validation and correction of execution dossiers;
- document-generation success and failure paths.

It is not, by itself, a sufficient schema source for end-to-end mortgage application intake, affordability assessment, underwriting, or approval workflows.

