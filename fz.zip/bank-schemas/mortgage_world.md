# Mortgage World

This is a conceptual entity map derived from the domain structures in `mps-common`. It deliberately shows entities and relationships only—no fields or transport-layer request/response wrappers.

```mermaid
flowchart LR
    subgraph Parties["Parties and institutions"]
        Client["Client"]
        Institution["Institution"]
        Notary["Notary"]
    end

    subgraph AgreementDomain["Mortgage agreement"]
        Agreement["Mortgage Agreement"]
        LoanPart["Loan Part"]
        ActiveLoan["Existing Loan to Repay"]
        Recalculation["Loan Recalculation"]
        NHG["NHG Guarantee"]
    end

    subgraph LoanEconomics["Loan economics"]
        LoanAccount["Loan Account"]
        AccountHolder["Account Holder"]
        ConstructionDepot["Construction Depot"]
        InterestTerms["Interest Rate Terms"]
        RateStructure["Rate Structure"]
        RateHistory["Interest Rate History"]
        RepaymentTerms["Repayment Terms"]
    end

    subgraph SecurityDomain["Collateral and legal security"]
        SecurityPackage["Security Package"]
        MortgageSecurity["Mortgage Security"]
        RegisteredProperty["Registered Property"]
        PropertyValuation["Property Valuation"]
        SecurityObjective["Security Objective"]
        MortgageOwner["Mortgage Owner"]
        PriorMortgage["Prior Mortgage Security"]
    end

    subgraph PledgeDomain["Pledges and insurance"]
        MoneyPledge["Money Pledge"]
        InsurancePolicy["Insurance Policy"]
        PolicyHolder["Policy Holder"]
        InsuredPerson["Insured Person"]
        Beneficiary["Beneficiary"]
        PledgeRestriction["Pledge Restriction"]
    end

    subgraph ExecutionDomain["Execution and settlement"]
        ExecutionSupplement["Execution Supplement"]
        InsuredParty["Insured Party"]
        Settlement["Settlement"]
    end

    subgraph DocumentDomain["Documents"]
        DocumentDossier["Document Dossier"]
        GeneratedDocument["Generated Document"]
    end

    Client -- "0..* participates in 1" --> Agreement
    Institution -- "0..* acts for 1" --> Agreement

    Agreement -- "1 contains 1..*" --> LoanPart
    Agreement -- "1 settles 0..*" --> ActiveLoan
    Agreement -- "1 has 0..*" --> Recalculation
    Agreement -- "1 may have 0..1" --> NHG

    Client -- "1 has 0..*" --> ActiveLoan
    Institution -- "1 finances 0..*" --> ActiveLoan

    LoanPart -- "1 uses 0..1" --> LoanAccount
    LoanAccount -- "1 has 0..*" --> AccountHolder
    LoanPart -- "1 may have 0..1" --> ConstructionDepot
    LoanPart -- "1 has 0..1" --> InterestTerms
    InterestTerms -- "1 uses 0..1" --> RateStructure
    LoanPart -- "1 records 0..*" --> RateHistory
    LoanPart -- "1 has 0..*" --> RepaymentTerms
    Recalculation -- "0..* recalculates 1..*" --> LoanPart

    Agreement -- "1 has 0..*" --> SecurityPackage
    SecurityPackage -- "1 contains 0..1" --> MortgageSecurity
    SecurityPackage -- "1 secures 0..1" --> RegisteredProperty
    SecurityPackage -- "1 includes 0..1" --> PropertyValuation
    SecurityPackage -- "1 states 0..1" --> SecurityObjective
    SecurityPackage -- "1 includes 0..*" --> PriorMortgage
    MortgageSecurity -- "1 encumbers 1" --> RegisteredProperty
    RegisteredProperty -- "1 has 0..*" --> PropertyValuation
    Client -- "1 may be 0..*" --> MortgageOwner
    MortgageOwner -- "0..* grants 1" --> MortgageSecurity
    Institution -- "1 may hold 0..*" --> PriorMortgage

    Agreement -- "1 is supported by 0..*" --> MoneyPledge
    MoneyPledge -- "1 pledges 1" --> InsurancePolicy
    InsurancePolicy -- "1 has 0..*" --> PolicyHolder
    InsurancePolicy -- "1 covers 0..*" --> InsuredPerson
    InsurancePolicy -- "1 names 0..*" --> Beneficiary
    MoneyPledge -- "1 has 0..*" --> PledgeRestriction
    Institution -- "1 issues 0..*" --> InsurancePolicy

    Agreement -- "1 has 0..1" --> ExecutionSupplement
    ExecutionSupplement -- "1 includes 0..*" --> InsuredParty
    ExecutionSupplement -- "1 defines 0..1" --> Settlement
    Settlement -- "0..* passes through 1" --> Notary
    Settlement -- "1 repays 0..*" --> ActiveLoan
    Settlement -- "1 funds 0..*" --> LoanAccount

    Agreement -- "1 produces 0..1" --> DocumentDossier
    DocumentDossier -- "1 contains 0..*" --> GeneratedDocument
    GeneratedDocument -- "0..* documents 1" --> Agreement
    GeneratedDocument -- "0..* may document 1" --> MortgageSecurity

    classDef central fill:#f6c85f,stroke:#6b4f00,stroke-width:3px,color:#1f1f1f
    classDef security fill:#dbeafe,stroke:#2563eb,color:#1f1f1f
    classDef execution fill:#dcfce7,stroke:#16a34a,color:#1f1f1f
    class Agreement central
    class SecurityPackage,MortgageSecurity,RegisteredProperty,PropertyValuation,SecurityObjective,MortgageOwner,PriorMortgage security
    class ExecutionSupplement,Settlement,Notary,DocumentDossier,GeneratedDocument execution
```

## Interpretation notes

- **Mortgage Agreement** is the conceptual center of this diagram. It is inferred from the loan-file and contract context; there is no literal `MortgageAgreement` Java class in the repository.
- **Loan Part** represents the individual loan components modeled by the loan overview and loan-details structures.
- **Mortgage Security** is the legal security registered over a property. It corresponds to the repository's `model.securities.Mortgage` concept and is intentionally separate from **Mortgage Agreement**.
- **Security Package** represents the `Securities` aggregate. The repository can carry old and new versions of this aggregate during an update.
- **Existing Loan to Repay** represents an existing mortgage or consumer loan selected for repayment or conversion during execution of the new agreement.
- **Institution** represents a reusable party that can act in several roles, such as lender, insurer, appraiser, mortgage holder, or land-registry-related institution.
- Request/response wrappers, validation envelopes, mapper types, and generated-PDF payloads are omitted because they are integration structures rather than mortgage-world entities.

