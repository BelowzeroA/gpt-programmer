# Related Repos — Missing Mortgage Domain Pieces

Survey of Azure DevOps (raboweb) repositories covering the missing mortgage
domain concepts listed in `missing_pieces.md`. The existing `mps-common`
repository (LCA/mps-common) covers mortgage offer/deed execution, agreement
administration, collateral registration, and document generation — this
report fills the gaps: pre-execution application/origination, affordability,
underwriting, evidence, advice/offer, valuation, compliance, completion,
and servicing.

Search method: fetched all 11,989 git repositories via the Azure DevOps
REST API (`/_apis/git/repositories`) from the authenticated Chrome browser
session (CDP port 9222), then filtered by domain keywords across 159
projects and inspected file trees + schema artifacts (SQL DDL/Flyway
migrations, JPA entities, XSD/WSDL contracts, OpenAPI specs, PlantUML
ERDs, test fixtures). All 42 repos from the previous (Aug 27) report were
verified against the current API listing — all still exist and resolve.

This report separates GENERAL LOAN / CORPORATE repos (Section A) from
MORTGAGE / RETAIL HOUSING repos (Section B), as requested. Section C
covers adjacent/compliance repos that are not mortgage-specific but
supply structures needed for end-to-end scenarios. A "NEW" tag marks
repos discovered in this refresh that were absent from the Aug 27 report.

========================================================================
SECTION A — GENERAL LOAN / CORPORATE (non-mortgage-specific)
========================================================================

These repos sit in the LCA project and cover the corporate/generic loan
contract lifecycle — separate from the retail mortgage (wonen-fpx) stack.

------------------------------------------------------------------------
A1. LCA/loancontractextension-api  (1.6 MB)  [Priority 8, 10]
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/LCA/_git/loancontractextension-api
Lifecycle stage: loan-contract execution, administration, audit.
Tech: Spring Boot + JPA/Hibernate + Flyway SQL migrations (HANA/H2).
Authoritative source: yes (DDL + ORM entities).
Sensitive fields: account number, IBAN, internal contract id, fiscal data.
Synthetic reuse: HIGH — cohesive schema with FK relationships and audit tables.

Key schemas:
  DDL (Flyway, 22 migrations):
    /src/main/resources/db/migration/V1_0__init.sql
      -> CMG_LOAN_CONTRACT_EXTENSION (id, product_class, internal_contract_id,
        account_number, iban, currency, bank_land, bank_key, code_conduct,
        original_end_date, green_status, created_by/time, changed_by/time)
    V1_1__audit.sql -> loan_contract_extension_rev, CMG_LOAN_CONTRACT_EXTENSION_AUD (Envers)
    V1_2__commercial_product_code.sql -> CMG_COMMERCIAL_PRODUCT_CODE (+AUD)
    V1_28__create_nhg_tables.sql -> WEW_ACCOUNT_LINK (NHG mortgage guarantee link)
    V1_33__...pricing_agreement_tables.sql -> SPA tables
    V1_20..V1_27 -> bridging loan, fiscal regime, break clause, loan arrangement fields
  JPA @Entity:
    /src/main/java/.../persistence/domain/LoanContractExtension.java
    LoanContractExtensionAudit, NHGLoanArrangement, NHGLoanClosure,
    CommercialProductCode, WewAccountLink,
    LoanArrangementSpecificPricingAgreement

Representative fields (LoanContractExtension entity):
  id, productClass, internalContractId, accountNumber, iban, currency,
  bankLand, bankKey, codeConduct, salesChannelCode, status, greenStatus,
  closedBy/closedTime, fiscalBox, fiscalRegimeBefore2013Flag, fiscalEndDate,
  bridgingLoanFlag, validFromDate, realEndDate, breakClauseFlag/period/exerciseDate,
  loanArrangementResidualDebtLoanFlag, adviceTypeCode, discountArrangementNumber,
  reasonCode, conditionsTypeCode, interestLoanToValueSurchargeCode,
  repaymentStrategyCode + List<CommercialProductCode>, List<WewAccountLink>,
  List<LoanArrangementSpecificPricingAgreement>

Remaining gaps: covers contract extension/admin only — no application intake,
no affordability, no underwriting decision, no servicing.

------------------------------------------------------------------------
A2. LCA/mps-loans  (10.2 MB)  [Priority 1, 2, 5]
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/LCA/_git/mps-loans
Lifecycle stage: loan arrangement read model, client reference, central rates.
Authoritative source: yes (domain DTOs).
Sensitive fields: client identity, relation number, dates of birth.
Synthetic reuse: MEDIUM — rich DTOs but no persistence/DDL.

Key schemas (model package, ~1030 files):
  model/client/Client.java
    name, postcode, houseNumber, gender, dateOfBirth, multiHeaded,
    privateBusiness, vr, officeNumber, relationNumber, nameIndex
  model/common/LoanArrangementKey.java
    administrativeBankCode (Integer), loanArrangementAccountNumber (Long)
  model/centralrates/CentralRatesPercentages.java
    groupCode, tariffStartDate, euriborStartDate, ratePerc01..ratePerc31
  model/autonomouscorrections/* -> AutonomousCorrectionDetail, List/Save requests
  model/availability/* -> ApplicationAvailability, BusinessHour
  model/codes/* -> DomainCode, DomainCodeDetails, CodeDescription

Remaining gaps: read-side models only — no write-side application aggregate.

------------------------------------------------------------------------
A3. LCA/mps-htc-scf  (3 MB)  [Priority 4, 8]
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/LCA/_git/mps-htc-scf
Lifecycle stage: settlement/closing — actions, closing statements, document lists.
Authoritative source: yes (DTOs under dto/).
Synthetic reuse: MEDIUM — execution-phase settlement DTOs.

Key schemas:
  dto/action/ActionDetailDTO, ActionDetailDocumentDTO, ActionDetailsDataDTO
  dto/closingStatement/ClosingStatementDto, ClosingStatementItemDto
  dto/documentlist/DocumentListDTO, DocumentListDetailDTO, DocumentDetailResponseDTO
  dto/cops/CopsDocumentIndicatorDTO
  dto/codes/CodeAggregationDto

------------------------------------------------------------------------
A4. LCA/valuationmanagement-api  (1.6 MB)  [Priority 6]  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/LCA/_git/valuationmanagement-api
Lifecycle stage: valuation management — collateral object valuation, appraisal.
Authoritative source: yes (Flyway DDL + JPA entities).
Synthetic reuse: HIGH — 13 SQL migrations with proper FK relations + audit.

Key schemas (DDL verified from V1_0__create_all_tables.sql):
  valuation_object_extension (id, valuation_object_number, category_code,
    type_code, no_valuation_reason_code, status_code, line_of_business_code,
    created_by/time, changed_by/time)
  valuation_object_extension_rev + valuation_object_extension_aud (Envers audit)
  valuation_details (valuation_object_id FK, valuation_date, type_code,
    method_code, model_type_code, valuation_amount, currency, appraiser_name,
    confidence_level, ref_desk_flag, status_code, approved_value_indicator)
  Additional tables across V1_1 through V1_12:
    vms_staging, adf_vms_desktoptaxatie_staging (desktop valuation import),
    nvax staging (non-AVM valuation staging)

This is the LCA-side valuation repository — covers the appraisal/AVM
workflow with status tracking, confidence levels, and desktop valuation
staging. Distinct from the retail-side valuation (which is embedded in
the dossier-compiling-service ERD).

------------------------------------------------------------------------
A5. LCA/red-management-api  (6.6 MB)  [Priority 4, 8, 10]  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/LCA/_git/red-management-api
Lifecycle stage: contract management — financial dossier creation, collateral.
Authoritative source: yes (87 Flyway migrations + 5 XSD contracts).
Synthetic reuse: HIGH — complete financial dossier schema with audit trail.

Key schemas:
  DDL (87 Flyway migrations):
    /src/main/resources/db/migration/V1_0__create_red_v2_tables.sql
    V1_10__quartz_tables.sql, V1_11..V1_13 (interim temp tables)
  XSD contracts:
    /src/main/resources/ws/createFinancialDossier/CreateFinancialDossier_v4.xsd
      -> CreateFinancialDossier V4: Collateral Giver, Collateral Object,
        Collateral Agreement, Construction Start Date, Completion Percentage,
        Rented/Usable/Residential Area, MarketabilityScore, OtherValuable,
        RecoveryPercentageOverride, Jurisdiction Country Code,
        RegisterInformation, CommitImmediateIndicator
    CreateFinancialDossier_v4_Envelope.xsd, CreateFinancialDossier_v4_Rpy.xsd
    Public_Service_Types.xsd, RaboGroupHeader.xsd

This is the corporate-loan financial dossier creation contract —
the LCA equivalent of the retail mortgage dossier. The XSD defines
collateral objects, agreements, and Basel IV fields.

------------------------------------------------------------------------
A6. LCA/fpx-ams-homefinancing-service  (9.5 MB)  [Priority 8]  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/LCA/_git/fpx-ams-homefinancing-service
Lifecycle stage: home financing service — actual balances, savings agreements.
Authoritative source: yes (32 WSDL/XSD contracts).
Synthetic reuse: HIGH — comprehensive SOAP contract library.

Key schemas (32 XSD files under wsdl/):
  wsdl/actualbalance/GetActualBalances_01_Req.xsd + _Rpy.xsd
  wsdl/azs/savingsAgreementROS_01_REQ.xsd + _RPY.xsd
  wsdl/cok/getacctcdtinf/GetAcctCdtInf_01_REQ.xsd (account credit info)
  ...plus 28 more WSDL/XSD contracts covering balance queries,
  savings agreement operations, and credit information retrieval

Module structure: fpx-ams-homefinancing-service-model (separate contract model)

------------------------------------------------------------------------
A7. LCA/green-declaration-api  (0.2 MB)  [Priority 10]  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/LCA/_git/green-declaration-api
Lifecycle stage: green/sustainability declaration for loans.
Authoritative source: yes (2 Flyway migrations + Envers audit).
Synthetic reuse: MEDIUM — small but with audit trail DDL.

Key schemas:
  /src/main/resources/db/migration/V1_0__init.sql (green declaration tables)
  /src/main/resources/db/migration/V1_1__audit.sql (Envers rev/aud tables)

Covers the sustainability/green-status dimension of loan contracts —
links to the greenStatus field in loancontractextension-api (A1).

------------------------------------------------------------------------
A8. Other LCA repos (supporting)
------------------------------------------------------------------------
LCA/loancontractextension-app  (1.2 MB)  NEW — application layer for A1
LCA/loanderivativelink-api  (0.6 MB) — loan-derivative link JPA entities
LCA/mps-arrangements (0.4 MB)  NEW — loan arrangement model package
LCA/mps-institutions (1.6 MB)  NEW — institution reference models
LCA/mps-common (1.5 MB)  NEW — the existing mps-common baseline (this repo's sibling)
LCA/read-loan-arrangement-details (0.033 MB) — read model for loan arrangement
LCA/non-real-estate-collateral-object-extension-api (2.3 MB) — NRE collateral schema
LCA/collateral-object-extension-app (2.3 MB) — TS frontend models: collateral.model.ts
LCA/collateral-object-additional-data-batch (0.1 MB)  NEW — batch collateral enrichment
LCA/construction-deposit-extension-api (0.6 MB)  NEW — construction deposit extension
LCA/indexation-batch (1.8 MB)  NEW — loan indexation batch processing
LCA/mps-htc-ab (2.6 MB)  NEW — HTC AB (settlement sub-module)
LCA/mps-echo (0.4 MB)  NEW — MPS echo/validation module
LCA/red-management-app (3.2 MB) — contract management application layer
LCA/ros-* repos (12 repos)  NEW — Retail Origination System:
  ros-account-number-pool, ros-app, ros-customer-arrangement,
  ros-customer-ascription, ros-customer-relation, ros-interest-correction-api,
  ros-master-data, ros-release-management, ros-saving-agreement,
  ros-service-request-activity, ros-user-data
LCA/zzz_* and zzz-* repos — archived/old versions (28 repos, skip)

========================================================================
SECTION B — MORTGAGE / RETAIL HOUSING (wonen-fpx platform)
========================================================================

The `wonen-fpx` project is the FPX (Financing Process eXperience) mortgage
platform — a microservice architecture with prefixes:
  mca = Mortgage Customer Application (the application/dossier aggregate)
  bwf = Berekeningen Wonen FPX (calculations engine — affordability/income)
  mirc = Mortgage Interest Rate Conditions (tariff/pricing)
  ics  = Insurance & Customer Services (document/statement management)
  mtp  = Mortgage Third-Party (GDP data, reconciliation, construction deposit)
  ric  = Rabobank Intermediary Channel (mortgage process orchestration)
  dhc  = Document Handling & Composition
  dho  = Document Handling Orchestration (fpx-document-engine)
  cag  = Customer AGgregate (financial positioning)
  med  = Mortgage Execution Dynamics (dynamic forms/intake questionnaires)
  fmf  = Funding & Mediation Financial (disbursement)
  pfa  = Process & Financial Assessment (customer financial assessment)
  pvc  = Process Validation & Control
  ngs  = New Generation Servicing

These repos map directly to the missing-pieces priorities.

========================================================================
B-PRIORITY 1: Mortgage application and origination
========================================================================

------------------------------------------------------------------------
B1.1 wonen-fpx/fpx-mca-dossier-compiling-service  (38.8 MB)  PRIMARY
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-dossier-compiling-service
Lifecycle stage: application/dossier aggregate (origination intake).
Authoritative source: YES — contains PlantUML ERD + domain-objects documentation.
Sensitive fields: person identity, income, birth dates, relation IDs.
Synthetic reuse: HIGH — the most complete mortgage-application domain model found.

Domain model (documentation/modules/ROOT/pages/05_building_block_view/domain/):
  domain-objects.adoc — CollateralObject: existingBuilding, newBuilding,
    selfConstruction, typeCode, location, constructionYear, energyLabel,
    energyLabelIssuedBefore2021Flag, dataSourceCode

ERD entities (PlantUML, ~48 .puml files):
  personnel/mortgage_dossier_person.puml -> mortgage_dossier_person (id, bankCode,
    birthDate, genderCode, sequenceNumber, siebelRelationId, hashedSiebelRelationId)
    + dependent_child_parent (FK), address, natural_person_name, ikb_relation
  incomes/income.puml -> income (id, endDate, grossSalaryIncVacationBonus,
    grossSalaryThirteenthMonth, grossSalaryVacationBonusPerc, startDate, typeCode,
    selfEmployedBusinessTypeCode, incomeProvider)
    + income_component, employment_relationship
  incomes/employment_relationship.puml -> employment_relationship (id,
    probationPeriodEndedFlag, declarationOfIntentFlag, declarationOfIntentType,
    declarationOfPerspectiveFlag, unconditionalIncomeRaiseFlag)
  financing_needs/financing_needs.puml -> financing_needs (id, ownMoneyAmount,
    mortgageDeedCostsAmount, compensationFeeAmount, exPartnerBuyOutAmount)
    + investment_goal
  scenario/scenario.puml -> scenario (id, name, customerNeedGroupCode,
    customerOwnsHomeFlag, customerHasHadMortgageFlag, hasMultipleHousesFlag,
    internalMovingOnCustomerFlag, breakUpFlag, hasBeenMarriedFlag, maritalStatusCode)
  nmo/consumer_credit.puml -> consumer_credit (id, balanceAmount, creditLimitAmount,
    typeCode) + product_identification
  nmo/student_loan.puml, nmo/private_lease.puml, nmo/alimony.puml,
    nmo/private_loan.puml, nmo/consumer_loan.puml, nmo/nmo_product_debtor.puml
  product_arrangement/loan_arrangement.puml -> loan_arrangement (loanArrangementId,
    remainingCapitalAmount, remainingCapitalBeforeBreakUpAmount, residualDebtFlag,
    nhgFlag, originalCapitalAmount, keepInterestRateFlag, interestTypeCode)
    + loan_arrangement_interest, bank_savings_arrangement, credit_arrangement
  purchase/purchase.puml -> purchase entity
  sale_home/sale_home.puml -> sale_home entity
  idtree/id_tree_dossier.puml -> id_tree_dossier (mortgageDossierId PK,
    nonMortgageObligationsId) -> has current_scenario, request_person,
    collateral_object, nmo_product (the full dossier aggregate root)

This is the missing application aggregate — the dossier is the first-class
case container with applicants, scenarios, collateral, incomes, obligations.

------------------------------------------------------------------------
B1.2 wonen-fpx/fpx-mca-saga-service  (7.4 MB)  WORKFLOW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-saga-service
Lifecycle stage: dossier/process state orchestration (saga pattern).
Authoritative source: yes (JPA entities + Flyway migrations).
Synthetic reuse: HIGH — process-state machine with persistence.

Key schemas:
  domain/dossierstate/DossierState.java, DossierId.java, DossierStateTypeCode.java
  domain/processstate/ProcessState.java
  core/dossierstate/model/DossierStateEntity.java, DossierIdEntity.java,
    DossierType.java, CreationUserTypeCode.java
  DDL:
    /src/main/resources/db/migration/V2022202209121600__add-index-dossier-state.sql
    V202229060930__4670106-add-creation-user-type-code.sql
    V2__Oracle_to_pgmigration.sql

Covers Priority 10 (workflow/state machine): DossierState lifecycle,
ProcessState tracking, CreationUserTypeCode enum.

------------------------------------------------------------------------
B1.3 wonen-fpx/fpx-mca-overview-service  (13.7 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-overview-service
Lifecycle stage: application overview, appointment, dossier creation, process.
Key schemas:
  api/dossier/model/CreateDossierRequest, CreateDossierResponse,
    CreateOrientationDossierResponse
  api/activity/model/ActivityRequest, Contact, RelationTelephone
  api/appoinment/model/AppointmentRequest, AvailableTimeslotResponse
  api/process/model/ProcessesResponse
  api/notification/model/NotificationResponse

------------------------------------------------------------------------
B1.4 wonen-fpx/fpx-mtp-managing-service  (47.7 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mtp-managing-service
Lifecycle stage: third-party application data, construction deposit, reconciliation.
Synthetic reuse: HIGH — contains SQL test fixtures with real schema shapes.

Key artifacts:
  src/integration-test/resources/.../repository/ApplicationJdbcRepositoryIT-data.sql
  src/integration-test/resources/.../repository/ApplicantJdbcRepositoryIT-data.sql
  src/integration-test/resources/.../repository/LoanArrangementRepositoryTest-data.sql
  src/integration-test/resources/.../gdp/GdpConstructionDepositRepositoryIT-data.sql
  src/integration-test/resources/.../gdp/GdpLoanArRepositoryIT-data.sql
  src/integration-test/resources/.../gdp/GdpRelXArAdsAaRepositoryIT-data.sql
  src/integration-test/resources/.../gdp/GdpRelationToRelationRepositoryIT-data.sql

------------------------------------------------------------------------
B1.5 wonen-fpx/fpx-mca-mortgage-dossier-sync-service  (4.8 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-mortgage-dossier-sync-service
Lifecycle stage: mortgage dossier synchronization (cross-service event sync).
Authoritative source: yes (Flyway DDL).
Synthetic reuse: MEDIUM — event/retry tables sketch the sync pattern.

Key schemas:
  /fpx-mca-mortgage-dossier-sync-service-app/src/main/resources/db/migration/
    V1__create_retryable_event_table.sql (event-driven sync with retry)
    V2__add_shedlock_table.sql (distributed lock for sync processing)

------------------------------------------------------------------------
B1.6 wonen-fpx/fpx-mca-dossier-managing-service  (6.9 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-dossier-managing-service
Lifecycle stage: dossier lifecycle management (CRUD operations on dossier).
444 files — API models for dossier management operations.

------------------------------------------------------------------------
B1.7 wonen-fpx/fpx-mca-sales-service  (3.2 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-sales-service
Lifecycle stage: sales/opportunity management for mortgage applications.
Authoritative source: yes (5 Flyway migrations — DDL with mortgageDossierId FK).
Synthetic reuse: MEDIUM — opportunity/quote lifecycle tables.

Key schemas:
  /fpx-mca-sales-service-app/src/main/resources/db/migration/
    V1__initial-schema.sql (sales/quote/opportunity tables)
    V2__alter_quote_modify_mortgagedossierid.sql (FK to dossier)
    V3__added_opportunity.sql (opportunity entity)
    V4__alter_opportunity_modify_mortgagedossierid.sql
    V5__drop_table_quote.sql

------------------------------------------------------------------------
B1.8 wonen-fpx/fpx-mca-employee-appointment-service  (61.5 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-employee-appointment-service
Lifecycle stage: employee appointment scheduling for mortgage consultations.
Authoritative source: yes (11 Flyway migrations).
Synthetic reuse: MEDIUM — appointment scheduling with queue/notification.

Key schemas:
  /fpx-mca-employee-appointment-service-app/src/main/resources/db/migration/
    V1__initial_setup.sql, V2__create_thank_you_letter_table.sql,
    V3__remove_field_senior.sql, V10__add_location_to_appointment.sql,
    V11__add_reason_to_send_appointment_queue.sql

------------------------------------------------------------------------
B1.9 wonen-fpx/fpx-med-dynamic-form-service  (6.3 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-med-dynamic-form-service
Lifecycle stage: dynamic intake forms (mortgage application questionnaires).
Authoritative source: yes (15 Flyway migrations).
Synthetic reuse: HIGH — form/question/category/prefill schema.

Key schemas:
  /fpx-med-dynamic-form-service-app/src/main/resources/db/migration/
    V10__add_column_to_category.sql, V11__drop_table_number_of_mandatory_questions.sql,
    V12__add_shedlock_table.sql, V13__add_category_group_templates_table.sql,
    V14__add_prefill_table.sql, V1..V9 (initial form/question/answer tables)

This is the mortgage intake questionnaire engine — dynamic forms with
categories, mandatory questions, prefill, and question groups.

------------------------------------------------------------------------
B1.10 wonen-fpx/fpx-mca-execution-only-service  (7.9 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-execution-only-service
Lifecycle stage: execution-only mortgage path (advice bypass / non-advised sales).
Authoritative source: yes (32 Flyway migrations — the largest new DDL set).
Synthetic reuse: HIGH — eligibility checks, BFS, dropout answers, DWH.

Key schemas:
  /fpx-mca-execution-only-service-app/src/main/resources/db/migration/
    V202403250951__initialSetup.sql (initial execution-only schema)
    V202404231415__addEligibilityAndBfs.sql (eligibility + BFS)
    V202406171409__addDropoutAnswer.sql (dropout/question flow)
    V202406171449__updateLimitsForDWH.sql (data warehouse limits)
    V202408111523__updateTablesWithTimestamps.sql ... and 27 more

The execution-only path is the non-advised mortgage channel — customers
who bypass advisor consultation. It encodes eligibility rules and BFS
(Basis Financiering Screening) checks for the no-advice route.

------------------------------------------------------------------------
B1.11 wonen-fpx/fpx-mca-financing-plan-service  (1.5 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-financing-plan-service
Lifecycle stage: financing plan composition (LTV, loan parts, check date).
Authoritative source: yes (6 Flyway migrations).
Synthetic reuse: HIGH — financing plan with LTV precision + financing entity.

Key schemas:
  /fpx-mca-financing-plan-service-app/src/main/resources/db/migration/
    V202408261411__initial_schema.sql (financing_plan tables)
    V202410040850__update_ltv_percentage_precision.sql (LTV % precision)
    V202410041128__ltv_percentage_not_null.sql (LTV constraint)
    V202410101526__add_check_date.sql (financial check date)
    V202410111533__add_financing_entity.sql (financing entity FK)

------------------------------------------------------------------------
B1.12 wonen-fpx/fpx-mca-investment-goals-service  (2.2 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-investment-goals-service
Lifecycle stage: investment goals (customer purpose for the mortgage).
320 files — investment goal models linked to the dossier.

------------------------------------------------------------------------
B1.13 wonen-fpx/fpx-mca-non-mortgage-obligations-service  (2.1 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-non-mortgage-obligations-service
Lifecycle stage: non-mortgage obligations (NMO: student loans, alimony, leases).
302 files — the NMO service that feeds into affordability calculations.
Links to the nmo/student_loan.puml, nmo/consumer_credit.puml entities in B1.1.

------------------------------------------------------------------------
B1.14 wonen-fpx/fpx-mca-current-house-service  (10.9 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-current-house-service
Lifecycle stage: current house situation (existing property/mortgage details).

------------------------------------------------------------------------
B1.15 wonen-fpx/fpx-pfa-service  (18.0 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-pfa-service
Lifecycle stage: Process & Financial Assessment (customer financial assessment).
Authoritative source: YES — 13 OpenAPI contracts + 5 JPA schema.sql files.
Synthetic reuse: HIGH — richest OpenAPI set in the platform.

Key schemas (13 OpenAPI/YAML contracts):
  /src/main/resources/open-api/cag/cag-fp.swagger.yml (financial positioning)
  /src/main/resources/open-api/crm/crm-household.swagger.yaml (household composition)
  /src/main/resources/open-api/crm/crm-identification-document-readonly.swagger.yaml
  ... plus 10 more OpenAPI specs covering financial assessment integrations
  Schema DDL:
    /src/main/resources/db/jpa/{dev,localhost,pa,prod,test}/schema.sql (per-env DDL)

========================================================================
B-PRIORITY 2: Applicant financial position and affordability
========================================================================

------------------------------------------------------------------------
B2.1 wonen-fpx/fpx-bwf-calculations  (148.2 MB)  PRIMARY CALC ENGINE
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-bwf-calculations
Lifecycle stage: affordability/income calculation (betaalbaarheid, leencapaciteit).
Authoritative source: yes (core calculation models).
Sensitive fields: income amounts, employment data.
Synthetic reuse: HIGH — the actual affordability calculation engine.

Key schemas (4583 files, calculation core + reference):
  calculations/inkomsten/model/
    InkomstenBerekeningInput.java, InkomstenBerekeningOutput.java
    IncomeSubType.java, InkomenType.java, SupplementIncomeTypeCode.java
    MappedInkomen.java, MappedInkomensPerAanvrager.java
  calculations/inkomsten/model/period/PeriodicValue.java, Term.java,
    TimeUnitTypeCode.java
  calculations/model/
    BerekeningAanvragerMoaCalc.java
    BerekeningAdviesAfsluitkostenComponent.java
    BerekeningBanksparenMoaCalc.java
    BerekeningBedragMoaCalc.java
    BerekeningConsumptiefKrediet.java

------------------------------------------------------------------------
B2.2 wonen-fpx/fpx-bwf-service  (146.2 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-bwf-service
Lifecycle stage: BWF calculation service (interest offer scenario calculations).
Authoritative source: yes (contract model module + WSDL/XSD).
10,433 files — the hosted calculation service with FT/release/testing modules.

Key schemas:
  XSD (5 files — Interest Offer V7):
    /fpx-bwf-service-client/src/main/wsdl/V7/InterestOffer.V7.Types.xsd
    /fpx-bwf-service-client/src/main/wsdl/V7/InterestOffer.V7.Request.xsd
    /fpx-bwf-service-client/src/main/wsdl/V7/InterestOffer.V7.Response.xsd
  Module: fpx-bwf-service-contract-model (separate contract model)
  Module: fpx-bwf-service-core (calculation core: scenario/homefinancing/v2)

The InterestOffer V7 XSD defines the interest-rate offer request/response
contract for mortgage scenario calculations.

------------------------------------------------------------------------
B2.3 wonen-fpx/fpx-bwf-reference-calculations  (46.2 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-bwf-reference-calculations
Lifecycle stage: reference calculation data (tariff grids, rate tables, norms).

------------------------------------------------------------------------
B2.4 wonen-fpx/fpx-mca-calculations-service  (11.6 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-calculations-service
Lifecycle stage: calculation API (income, interest, loan arrangement, real obligations).
Key schemas:
  api/income/model/TotalYearIncomeResponse.java
  api/interestperiods/model/InterestPeriodsRequest/Response.java
  api/interestratepercentages/model/InterestRatePercentage(s)Response.java
  api/loanarrangements/model/LoanArrangementRequest/Response.java
  api/realobligations/model/RealObligationResponse.java
  api/additionalcosts/model/AdditionalCostsResponse.java
  client/calculations/common/model/CustomerNeedGroupTypeCode.java,
    RealEstateTypeCode.java, SustainabilityDto.java

------------------------------------------------------------------------
B2.5 wonen-fpx/fpx-mca-supplement-incomes-service  (7.3 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-supplement-incomes-service
Lifecycle stage: supplement/alternative income (self-employed, rental, pension).

------------------------------------------------------------------------
B2.6 wonen-fpx/fpx-cag-financial-positioning-service  (37.7 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-cag-financial-positioning-service
Lifecycle stage: applicant financial position (existing arrangements, consumptive finance).
Key schemas:
  api/capitalinsurance/model/CapitalInsurance, Coverage, CoverageRole,
    InvolvedParty, LifeInsurance, PolicyComponent
  api/common/arrangement/model/ArrangementPartyResponseModel
  api/common/consumptivefinance/model/Arrangement, BasicPaymentAgreement,
    ConsumptiveCreditArrangement, ConsumptiveFinancingAccount,
    ConsumptiveLoanArrangement, CreditResponseModel, CurrentAccountBalance

------------------------------------------------------------------------
B2.7 wonen-fpx/fpx-bwf-historic-loan-to-income-check-service  (7.1 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-bwf-historic-loan-to-income-check-service
Lifecycle stage: LTI check (loan-to-income) for historic loans.

------------------------------------------------------------------------
B2.8 wonen-fpx/fpx-bwf-acceptance-data-home-financing-service  (6.3 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-bwf-acceptance-data-home-financing-service
Lifecycle stage: acceptance data for home financing (acceptatiegegevens).
Authoritative source: yes (OpenAPI 3.0 spec).
1,917 files — acceptance parameter data for the calculation engine.

Key schemas:
  OpenAPI:
    /fpx-bwf-acceptance-data-home-financing-service-api/src/main/resources/static/openapi/
      local/v1/scenario/woningfinanciering/acceptatiegegevens/
      acceptatiegegevens_woningfinanciering_v1.yml
  -> defines acceptance parameters for woningfinanciering (home financing) scenarios

========================================================================
B-PRIORITY 3: Underwriting, credit risk, and acceptance
========================================================================

------------------------------------------------------------------------
B3.1 wonen-fpx/fpx-ric-service  (57.2 MB)  MORTGAGE PROCESS ORCHESTRATION
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-ric-service
Lifecycle stage: mortgage process orchestration (decision, opportunity, checks, quote).
Authoritative source: yes (API models, enums).
Sensitive fields: relation ID, employee ID, bank code.
Synthetic reuse: HIGH — decision/approval-level enum is the acceptance model.

Key schemas:
  api/mortgageprocess/decision/v1/model/DecisionV1.java
    acceptanceRuleApprovalLevelCodes: List<AcceptanceRuleApprovalLevelCode>
    mortgageApplicationChannelCode, mortgageApplicationApprovalLevelCode,
    processTrackNumber, employeeId, bankCode, orderId, unitOfWorkIds, relationId
  api/mortgageprocess/decision/v1/model/AcceptanceRuleApprovalLevelCode.java
    enum: ACCEPTANT, MEDIOR_ACCEPTANT, SENIOR_ACCEPTANT, RISK, FRAUDE,
         GEDEELTELIJKE_GOEDKEURING, BIJZONDER_BEHEER, GELDVERSTREKKER
  api/mortgageprocess/opportunity/v1/model/OpportunityRequestV1.java
    opportunityId, processTrackNumber, mortgageApplicationChannelCode,
    winProbabilityCode, sourceTypeCode, priorityCode, description, comment,
    activities, bankCode, applicants, employeeId
  api/checks/common/model/ChecksRequest.java (List<CheckModel>)
  api/checks/v1/model/ChecksResultsResponseV1.java
  api/checks/v2/model/ChecksExecutionSummaryResponseV2.java
  api/customerrecognition/v1/model/CustomerRecognitionRequestV1,
    CustomerRecognitionResultV1
  api/quote/v1/model/QuoteResponse, SaveQuoteRequest, SaveQuoteResponse
  api/relation/common/model/AddressResponse, BirthResponse, LocalBankResponse,
    NaturalPersonNameResponse

------------------------------------------------------------------------
B3.2 CJIP/checksmate-CKI  (1.5 MB)  CREDIT BUREAU CONTRACTS
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/CJIP/_git/checksmate-CKI
Lifecycle stage: credit-bureau inquiry (CKI/BKR toetsing).
Authoritative source: YES — XSD schemas are the authoritative wire contracts.
Sensitive fields: full credit-bureau PII (name, DOB, address, BKR/CKI codes).
Synthetic reuse: HIGH for event/contract generation; MEDIUM for DB seed.

Key schemas:
  /src/main/resources/cki.xsd -> "Toetsing" root, Header (OmgevingIndicator,
    GebruikersID), credit-inquiry request/response structure (BKR protocol 2.2.15)
  /src/main/resources/bkr/bkr.xsd -> BKR credit-registration schema
  /src/main/resources/bkr/bkrbatchckitoetsen.xsd -> batch CKI toetsen
  /src/main/resources/bkr/bkrVerwerkingsBevestiging.xsd -> processing confirmation
  /src/main/resources/bkr/bkrStatusBatchIDs.xsd -> status batch IDs
  /src/main/resources/statusBatchIDs.xsd, verwerkingsBevestiging.xsd

Covers Priority 3 completely: credit bureau inquiry, BKR/CKI, decision reason codes.

------------------------------------------------------------------------
B3.3 Tribe Housing/dmac-ha-mortgage-underwriting-engine  (2.4 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/Tribe%20Housing/_git/dmac-ha-mortgage-underwriting-engine
Lifecycle stage: automated underwriting evaluation (async job).
Authoritative source: OpenAPI 3.0.1 spec.
Synthetic reuse: MEDIUM — API shape (evaluate/status/result) but request body
  schema is in a separate model definition (not in the openapi preview).

OpenAPI:
  /src/containerapps/openapi/read/openapi.json
    title: "MUE Async API service running on FastAPI"
    POST /api/v1/underwriting/evaluate -> evaluate mortgage underwriting
    GET  /api/v1/underwriting/status/{job_id} -> job status
    GET  /api/v1/underwriting/result/{job_id} -> underwriting result

------------------------------------------------------------------------
B3.4 CJIP/muh-overrule-service  (1.2 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/CJIP/_git/muh-overrule-service
Lifecycle stage: manual underwriting override (vierogenprincipe / four-eyes).
Covers: policy exception, override, escalation, dual approval (Priority 3/10).

------------------------------------------------------------------------
B3.5 CJIP/muh-acceptance-service  (67.1 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/CJIP/_git/muh-acceptance-service
Lifecycle stage: mortgage underwriting acceptance (acceptatiebeslissing).
67.1 MB — the acceptance engine behind manual underwriting decisions.

------------------------------------------------------------------------
B3.6 CJIP/muh-cssr  (4.6 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/CJIP/_git/muh-cssr
Lifecycle stage: mortgage underwriting CSSR (Credit Scoring & Risk).

------------------------------------------------------------------------
B3.7 CJIP/muh-routing-service  (2.9 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/CJIP/_git/muh-routing-service
Lifecycle stage: mortgage underwriting routing (decision routing to accept/reject/override).

------------------------------------------------------------------------
B3.8 wonen-fpx/fpx-mca-knowledge-experience-check-service  (1.4 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-knowledge-experience-check-service
Lifecycle stage: knowledge & experience check (suitability assessment).
Authoritative source: yes (19 Flyway migrations).
Synthetic reuse: HIGH — exam/knowledge check lifecycle with participant tables.

Key schemas:
  /src/main/resources/db/migration/
    V202306141156__initialSetup.sql (exam tables)
    V202306282005__updateExamStatus.sql (exam status enum)
    V202306301315__addStartExamDateTime.sql (exam timing)
    V202403150952__addRelationIdAndParticipantTable.sql (participant + relation)
    V202405211519__addDossierId.sql (link to dossier)

This is the passend advies (suitability) check — verifies the customer's
knowledge and experience level before recommending a mortgage product.

------------------------------------------------------------------------
B3.9 wonen-fpx/fpx-mwo-close-mortgage-credit  (0 MB — empty/archived)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mwo-close-mortgage-credit
Lifecycle stage: closing mortgage credit decision (possibly migrated/merged).

========================================================================
B-PRIORITY 4: Evidence and document collection
========================================================================

------------------------------------------------------------------------
B4.1 wonen-fpx/fpx-mca-documentlist-service  (8.8 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-documentlist-service
Lifecycle stage: required-document checklist per applicant.
Authoritative source: yes (DTOs with validation).
Synthetic reuse: HIGH — checklist + applicant + document + status lifecycle.

Key schemas:
  api/documentlist/model/ApplicantDto.java, DocumentDto.java, DocumentListDto.java,
    FileDto.java, TagDto.java, CustomTagDto.java, DocumentComposeDto.java
  api/documentlist/model/save/ApplicantSaveDto, DocumentListSaveDto,
    DocumentSaveDto, TagSaveDto, CustomTagSaveDto (+ validation package)
  api/advicedocumentlist/model/AdviceDocumentDto, AdviceDocumentListDto,
    ExternalStatusUpdateDto

------------------------------------------------------------------------
B4.2 wonen-fpx/fpx-mca-validation-documents-service  (8.4 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-validation-documents-service
Lifecycle stage: document validation — expiry, rejection reasons, upload reminders.
Key schemas:
  api/validation/model/ValidationDto, ValidationRequest, FileExpirationDto,
    RejectionReasonDto
  api/documents/model/DocumentsResponseDto, DocumentDto, FileDto
  api/notifications/model/NotificationDto, NotificationDocumentDto
  clientkafka/rmh/model/DocumentGroupDto, UploadReminderDto,
    productdata/Documents, Med, UploadReminder

------------------------------------------------------------------------
B4.3 wonen-fpx/fpx-mca-upload-customer-document-service  (6.3 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-upload-customer-document-service
Lifecycle stage: customer document upload (the evidence-collection entry point).

------------------------------------------------------------------------
B4.4 wonen-fpx/fpx-upload-gathering-gateway  (0.8 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-upload-gathering-gateway
Lifecycle stage: upload gateway/aggregation.

------------------------------------------------------------------------
B4.5 wonen-fpx/fpx-mca-document-dossier-management-service  (10.0 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-document-dossier-management-service
Lifecycle stage: document dossier management + evidence dossier lifecycle.
Authoritative source: yes (23 Flyway migrations — the largest document DDL).
Synthetic reuse: HIGH — document + evidence dossier + status lifecycle.

Key schemas:
  /fpx-mca-document-dossier-management-service-app/src/main/resources/db/migration/
    V1..V10 (initial document dossier tables, ShedLock for processing)
    V11__add_evidence_dossier.sql (evidence dossier entity)
    V12__add_updatedOn_to_evidence_dossier.sql
    V14__add_status_changed_on_column_to_document_dossier_table.sql (status lifecycle)
    V15__add_dmsDossierCreatedOn_to_evidence_dossier.sql (DMS integration)
    ... and 8 more (total 23 migrations)

This is the evidence/document dossier lifecycle service — tracks required
documents per dossier with status changes, evidence dossier links,
DMS creation timestamps, and ShedLock processing.

------------------------------------------------------------------------
B4.6 wonen-fpx/fpx-mca-document-handling-service  (11.6 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-document-handling-service
Lifecycle stage: document handling — storage, status, type enforcement, PDF generation.
Authoritative source: yes (4 Flyway migrations + 3 XSD contracts).
Synthetic reuse: HIGH — document + dossier summary + WPI data contracts.

Key schemas:
  DDL:
    /fpx-mca-document-handling-service-app/src/main/resources/db/migration/
      V20211029__migration_from_oracle.sql (initial schema)
      V20220120__enforce_max_one_document_per_type_per_dossier.sql (constraint)
      V202312111526__Decom_BMMZ_MortgageDeclaration.sql
      V202406180810__Add_pdf_column.sql
  XSD contracts:
    /fpx-mca-document-handling-service-app/src/main/resources/inspire/document/
      Document.xsd (generic document schema)
      DossierSummary-v1.xsd (dossier summary contract)
      rabobank_wpi_datav09.1.xsd (WPI data — Work Process Instructions)

------------------------------------------------------------------------
B4.7 wonen-fpx/fpx-dhc-generating-service  (66.3 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-dhc-generating-service
Lifecycle stage: document generation (PDF generation from mortgage data).
Authoritative source: YES — 21 XSD contracts for document types.
Synthetic reuse: HIGH — authoritative document-type schemas.

Key schemas (21 XSD files under inspire/document/):
  ApplicationFinancingPrivate-v1.xsd (private mortgage application document)
  AccompanyingLetter-v1.xsd (cover letter)
  CounterGuarantee-v1.xsd (NHG counter-guarantee)
  EuropeanStandardInformationSheet-v1.xsd (ESIS — European mortgage info sheet)
  Document.xsd (base document type)
  ... plus 16 more document-type XSDs

These XSDs define the structure of every generated mortgage document —
the authoritative schema for the output of the document generation pipeline.

------------------------------------------------------------------------
B4.8 wonen-fpx/fpx-dhc-managing-service  (36.6 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-dhc-managing-service
Lifecycle stage: document management (archiving, status, Oracle migration).
Authoritative source: yes (12 Flyway migrations + 3 PlantUML C4 diagrams).
Synthetic reuse: HIGH — archivable document management with auditrawl.

Key schemas:
  DDL:
    /fpx-dhc-managing-service-app/src/main/resources/db/migration/
      V1__migrationFromOracle.sql, V2..V3 (status fixes)
      V10__add_archivable_json_column.sql (JSON archiving)
  Architecture diagrams:
    /docs/architecture/diagrams/c4-level1-context.puml
    /docs/architecture/diagrams/c4-level2-container.puml
    /docs/architecture/diagrams/c4-level3-components.puml

------------------------------------------------------------------------
B4.9 wonen-fpx/fpx-document-engine-service  (53.6 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-document-engine-service
Lifecycle stage: document engine (content recognition save, document type tables).
Authoritative source: yes (14 Flyway migrations + domain module).
Synthetic reuse: HIGH — content recognition + save result + document tables.

Key schemas:
  DDL:
    /app/src/main/resources/db/migration/
      V1.0.0__Initial_migration.sql
      V1.0.1__create_cr_save_result_file_event_table.sql (content recognition results)
      V1.0.2__create_cr_save_data_event_table.sql
      V4.0.0__Create_cr_document_tables.sql (document type tables)
      V4.0.1__update_cr_save_data_event_table.sql
      ... and 9 more
  Domain module: /domain/ (separate domain model)

------------------------------------------------------------------------
B4.10 wonen-fpx/fpx-ics-document-list-service  (2.9 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-ics-document-list-service
Lifecycle stage: ICS document list (insurance & customer services documents).

------------------------------------------------------------------------
B4.11 wonen-fpx/fpx-ics-dossier-service  (5.0 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-ics-dossier-service
Lifecycle stage: ICS dossier (insurance dossier lifecycle).
Authoritative source: yes (65 Flyway migrations — very large DDL set).

Key schemas:
  /fpx-ics-dossier-service-app/src/main/resources/db/migration/
    V202504020913__initial_schema.sql (dossier + owner + company)
    V202504091451__add_owner_and_company.sql
    V202504181351__change_string_to_number.sql
    V202504221643__add_document.sql (document table)
    ... and 61 more (total 65 migrations)

------------------------------------------------------------------------
B4.12 wonen-fpx/fpx-rabobank-required-data-documents  (2.6 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-rabobank-required-data-documents
Lifecycle stage: required data documents (consumer data session + applicant reference).
Authoritative source: yes (7 Flyway migrations).

Key schemas:
  /fpx-rabobank-required-data-documents-app/src/main/resources/db/migration/
    V202410011333__create-consumer-data-session-table.sql
    V202410161432__alter-column-last-updated-by-and-session-url.sql
    V202410231705__alter-column-id-to-uuid.sql
    V202501271136__add-column-applicant-reference.sql (applicant -> data session)
    V202501281130__add-column-has-error-and-retry-count.sql

------------------------------------------------------------------------
B4.13 ContentRecognition/Rabobank.Dm.ContentAnalyzer  (3.4 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/rabobank/ContentRecognition/_git/Rabobank.Dm.ContentAnalyzer
Lifecycle stage: OCR / structured extraction from uploaded documents.

------------------------------------------------------------------------
B4.14 ContentRecognition/Rabobank.Dm.Idh  (42.0 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/rabobank/ContentRecognition/_git/Rabobank.Dm.Idh
Lifecycle stage: Intelligent Document Handling (full IDH pipeline).
Covers: payslip/ID/bank-statement extraction, classification (Priority 4 OCR).

========================================================================
B-PRIORITY 5: Advice, product selection, pricing, and offer creation
========================================================================

------------------------------------------------------------------------
B5.1 wonen-fpx/fpx-mirc-tariff-definition  (2.1 MB)  TARIFF MODEL
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mirc-tariff-definition
Lifecycle stage: tariff/interest-rate definition (product pricing catalogue).
Authoritative source: yes (core model + OpenAPI/Swagger).
Synthetic reuse: HIGH — tariff template with status/usage modes.

Key schemas:
  core/model/InterestBenchmark.java, InterestType.java,
    MortgageConditionType.java, MortgageLoanType.java,
    TariffTemplateStatus.java (enum), TariffTemplateUsageMode.java,
    UsageMode.java, UserType.java
  core/model/converter/ (JPA converters for each enum)
  api/openapi/OpenApiConfiguration.java, SwaggerController.java
  common/logging/event/Events.java

------------------------------------------------------------------------
B5.2 wonen-fpx/fpx-mirc-tariff-validation  (1.7 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mirc-tariff-validation
Lifecycle stage: tariff validation rules.

------------------------------------------------------------------------
B5.3 wonen-fpx/fpx-mirc-tariff-distribution  (1.1 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mirc-tariff-distribution
Lifecycle stage: tariff distribution to channels.

------------------------------------------------------------------------
B5.4 wonen-fpx/fpx-mortgage-interest-service  (8.8 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mortgage-interest-service
Lifecycle stage: mortgage interest rate service (quote/offer pricing).
Key schemas:
  model/InterestRateDataCollection, InterestRateTable, InterestRateKey,
    PaymentConditions, TermsAndConditions, RepaymentMethod,
    ConstantsApiResponse

------------------------------------------------------------------------
B5.5 wonen-fpx/fpx-mca-premium-indication-service  (1.9 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-premium-indication-service
Lifecycle stage: premium indication (insurance premium estimate during application).
Authoritative source: yes (6 Flyway migrations).

Key schemas:
  /fpx-mca-premium-indication-service-app/src/main/resources/db/migration/
    V202404041333__add-premium-indication-data-table.sql (premium indication table)
    V202404191000__alter-collateral-type-family-composition-columns.sql
    V202404231705__replace-siebel-relation-id-with-dossier-id.sql (FK to dossier)

------------------------------------------------------------------------
B5.6 wonen-fpx/fpx-mirc-cost-retrieval  (4.0 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mirc-cost-retrieval
Lifecycle stage: tariff cost retrieval (retrieving cost components for pricing).

========================================================================
B-PRIORITY 6: Property acquisition and valuation workflow
========================================================================

------------------------------------------------------------------------
B6.1 wonen-fpx/fpx-mca-dossier-compiling-service  (see B1.1)
------------------------------------------------------------------------
The ERD already covers: collateral_object (existing_building, new_building,
self_construction, real_estate, location, address, construction_plan),
purchase, sale_home. This is the property-side model.

------------------------------------------------------------------------
B6.2 LCA/valuationmanagement-api  (see A4 — NEW, 1.6 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/LCA/_git/valuationmanagement-api
13 Flyway migrations: valuation_object_extension, valuation_details,
vms_staging, adf_vms_desktoptaxatie_staging (desktop valuation/AWM).
Verified DDL: valuation_amount, appraiser_name, confidence_level,
ref_desk_flag, status_code, method_code, model_type_code.

------------------------------------------------------------------------
B6.3 wonen-fpx/fpx-mca-current-house-service  (10.9 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-current-house-service
Lifecycle stage: current house situation (existing property + mortgage details).
Key concept: encodes the "customer currently owns/rents" state — feeds the
scenario.customerOwnsHomeFlag / hasBeenMarriedFlag in the dossier ERD.

------------------------------------------------------------------------
B6.4 Operations en Ketens Support Financieren/FIN_FRR_TAXATIE_MACRO  (0.4 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/Operations%20en%20Ketens%20Support%20Financieren/_git/FIN_FRR_TAXATIE_MACRO
Lifecycle stage: macro-level valuation/taxatie processing.

------------------------------------------------------------------------
B6.5 Enterprise Data Lake - Airflow/af-westeurope-if-bag-rabotaxatie
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/Enterprise%20Data%20Lake%20-%20Airflow/_git/af-westeurope-if-bag-rabotaxatie
Lifecycle stage: BAG (Dutch building registry) + Rabo valuation data pipeline.

------------------------------------------------------------------------
B6.6 wonen-fpxsu/fpx-interconnection-nhg  (0.6 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpxsu/_git/fpx-interconnection-nhg
Lifecycle stage: NHG (Nationale Hypotheek Garantie) interconnection.

========================================================================
B-PRIORITY 7: Compliance, identity, fraud, and financial crime
========================================================================

The KYC/CDD/AML domain is large (182 repos) but mostly in Tribe Investments
(kyca-*), Tribe Data and Analytics (AAA_DATAIKU_BCK_CDD_*), and CJIP
(onboarding-*). The mortgage-specific compliance path runs through:

------------------------------------------------------------------------
B7.1 CJIP/onboarding-individuals  (35 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/CJIP/_git/onboarding-individuals
Lifecycle stage: customer onboarding (identity verification, CDD for individuals).
Covers: identity verification, CDD, Wwft checks.

------------------------------------------------------------------------
B7.2 CJIP/onboarding-organisations-service  (55 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/CJIP/_git/onboarding-organisations-service
Lifecycle stage: organisational onboarding (UBO/beneficial owner, CDD).
Covers: beneficial ownership, UBO, enhanced due diligence.

------------------------------------------------------------------------
B7.3 wonen-fpx/fpx-ric-service — customerrecognition API (see B3.1)
------------------------------------------------------------------------
api/customerrecognition/v1/model/CustomerRecognitionRequestV1,
CustomerRecognitionResultV1 — identity recognition within the mortgage flow.

------------------------------------------------------------------------
B7.4 wonen-fpx/fpx-mca-knowledge-experience-check-service  (see B3.8 — NEW)
------------------------------------------------------------------------
The knowledge & experience check is part of the passend advies suitability
assessment regulated under the Wft (financial supervision act).

------------------------------------------------------------------------
B7.5 CJIP/risk-shield-scanner  (1.5 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/CJIP/_git/risk-shield-scanner
Lifecycle stage: fraud risk scanning (device risk, document fraud screening).

------------------------------------------------------------------------
B7.6 Tribe Investments/kyca-* repos (KYC/CDD platform)
------------------------------------------------------------------------
Key repos:
  kyca-goal-monitor-service (1.1 MB) — KYC goal monitoring
  kyca-commons-security-spring-boot-starter (0.5 MB) — shared security
  kyca-pcf-space (8.8 MB) — KYC PCF space
  kyca-starting-points-service (6 MB) — KYC starting points
These are the enterprise KYC/CDD platform — onboarding, screening, monitoring.

========================================================================
B-PRIORITY 8: Completion, funding, and disbursement
========================================================================

------------------------------------------------------------------------
B8.1 wonen-fpx/fpx-financing-mediation-service  (4.3 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-financing-mediation-service
Lifecycle stage: financing mediation (funding instruction orchestration).
Authoritative source: yes — JPA entity + XSD contracts + DDL.
Synthetic reuse: HIGH — has Dossier entity + HDN XSD message contracts.

Key schemas:
  /src/main/java/.../entity/Dossier.java
  /src/main/resources/db/migration/V1__init.sql
  /src/main/xsd/hdn25/  -> hdn25_brp.xsd, hdn25_cbb.xsd, hdn25_message.xsd,
    hdn25_pob.xsd, hdn25_slb.xsd (HDN = Hypotheek Data Netwerk, the Dutch
    mortgage data interchange standard v2.5)
  /src/main/xsd/hdn26/  -> HDN v2.6 schemas

This is critical — HDN is the standard message format for mortgage data
exchange in the Netherlands. The XSDs define the complete mortgage message
structure (BRP=persons, CBB=conditions, POB=products, SLB=loans).

------------------------------------------------------------------------
B8.2 wonen-fpx/fpx-financing-mediation-gui  (17.4 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-financing-mediation-gui
Lifecycle stage: financing mediation GUI (frontend for the HDN mediation flow).

------------------------------------------------------------------------
B8.3 wonen-fpx/fpx-fmf-disburse-service  (1.9 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-fmf-disburse-service
Lifecycle stage: disbursement service (funding disbursement).
249 files — the FMF (Funding & Mediation Financial) disbursement module.

------------------------------------------------------------------------
B8.4 wonen-fpx/fpx-fmp-provisioning-service  (3.2 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-fmp-provisioning-service
Lifecycle stage: provisioning service (funding mediation provisioning).
516 files — FMP (Funding Mediation Provisioning) setup before disbursement.

------------------------------------------------------------------------
B8.5 wonen-fpx/fpx-rfh-reconciling-service  (4.3 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-rfh-reconciling-service
Lifecycle stage: reconciling service (funding reconciliation + HTC).
Authoritative source: yes (13 Flyway migrations + 1 XSD).

Key schemas:
  DDL:
    /src/main/resources/db/migration/
      V1__init.sql, V2..V10 (HTC tables, column adjustments)
      V10__createHTCTables.sql (HTC = Handelings TerugKoppeling = action feedback)
  XSD:
    /src/main/resources/client/force2htc/v3/HtcV9.xsd (HTC v9 force contract)

------------------------------------------------------------------------
B8.6 LCA/mps-htc-scf  (see A3)
------------------------------------------------------------------------
Closing statement + action DTOs cover the completion/settlement artifacts.

========================================================================
B-PRIORITY 9: Post-completion mortgage servicing
========================================================================

Servicing is the weakest area — most mortgage servicing is handled outside
the FPX platform (Pega, mainframe, or Tribe Payments).

------------------------------------------------------------------------
B9.1 wonen-fpx/fpx-mca-operations-service  (2.9 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-operations-service
Lifecycle stage: mortgage operations (post-completion servicing operations).

------------------------------------------------------------------------
B9.2 wonen-fpx/fpx-ics-statement-managing-service  (33.1 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-ics-statement-managing-service
Lifecycle stage: statement management (annual statements, tax statements).

------------------------------------------------------------------------
B9.3 wonen-fpx/fpx-ics-operations-service  (0.7 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-ics-operations-service
Lifecycle stage: ICS operations (insurance & customer services operational tasks).

------------------------------------------------------------------------
B9.4 wonen-fpx/fpx-ics-overview-service  (8.2 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-ics-overview-service
Lifecycle stage: ICS overview (insurance & customer services overview/dashboard).

------------------------------------------------------------------------
B9.5 wonen-fpx/fpx-ics-indicative-income-statement-frontend  (0.02 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-ics-indicative-income-statement-frontend
Lifecycle stage: indicative income statement (customer-facing income overview).

------------------------------------------------------------------------
B9.6 Tribe Payments/Pega-EuroIncasso  (5 KB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/Tribe%20Payments/_git/Pega-EuroIncasso
Lifecycle stage: direct-debit/EuroIncasso (payment collection).

------------------------------------------------------------------------
B9.7 Enterprise Data Lake - Airflow/af-westeurope-vista-rabo-forbearance
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/Enterprise%20Data%20Lake%20-%20Airflow/_git/af-westeurope-vista-rabo-forbearance
Lifecycle stage: forbearance data pipeline (bijzonder beheer).

------------------------------------------------------------------------
B9.8 Operations en Ketens Support Financieren/FIN_LF_Achterstandsbrieven
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/Operations%20en%20Ketens%20Support%20Financieren/_git/FIN_LF_Achterstandsbrieven
Lifecycle stage: arrears letters (achterstandsbrieven — collections correspondence).

------------------------------------------------------------------------
B9.9 Operations en Ketens Support Financieren/FIN_COZ_BeheerAfspraken
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/Operations%20en%20Ketens%20Support%20Financieren/_git/FIN_COZ_BeheerAfspraken
Lifecycle stage: servicing agreements management (beheer afspraken).

------------------------------------------------------------------------
B9.10 wonen-fpx/fpx-mtp-process-manager  (1.8 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mtp-process-manager
Lifecycle stage: MTP process manager (third-party process orchestration).
Authoritative source: yes (11 XSD + 3 OpenAPI contracts).

Key schemas:
  XSD (11 files — activity/service-request contracts):
    /src/main/resources/jaxb/xsd/CreateActivities_3_REQ.xsd + _RPY.xsd
    /src/main/resources/jaxb/xsd/CreateServiceRequest_2_REQ.xsd + _RPY.xsd
    /src/main/resources/jaxb/xsd/QueryServiceRequest_3_REQ.xsd
    ... plus 6 more
  OpenAPI (3 files):
    /src/main/resources/openapi/api/api.yml
    /src/main/resources/openapi/client/Registrations_Read_Updated.yml
    /src/main/resources/openapi/client/fpx-mtp-managing-service.yml

Remaining gaps in servicing: amortization ledger, rate-reset/renewal,
early-redemption penalty, contract modification, complaints — not found as
first-class schemas. These likely live in the mainframe or Pega systems not
exposed in Azure DevOps.

========================================================================
B-PRIORITY 10: Cross-cutting workflow and agentic-scenario structures
========================================================================

------------------------------------------------------------------------
B10.1 wonen-fpx/fpx-mca-saga-service  (see B1.2)
------------------------------------------------------------------------
The saga service is the workflow/state-machine backbone:
  DossierState / DossierStateTypeCode (state enum)
  ProcessState (per-process tracking)
  CreationUserTypeCode (actor identity)
  Flyway migrations persist the state tables
This is the best source for agentic scenario state machines.

------------------------------------------------------------------------
B10.2 wonen-fpx/fpx-construction-deposit-workflow-admin  (0.018 MB)
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-construction-deposit-workflow-admin
Lifecycle stage: construction-deposit workflow (bouwdepot drawdown admin).

------------------------------------------------------------------------
B10.3 fpx-ric-service mortgageprocess API (see B3.1)
------------------------------------------------------------------------
The mortgageprocess/decision and mortgageprocess/opportunity APIs encode
process track numbers, activities, and decision workflows — directly usable
for agentic scenario orchestration.

------------------------------------------------------------------------
B10.4 wonen-fpx/fpx-mtp-process-manager  (see B9.10 — NEW)
------------------------------------------------------------------------
11 XSD activity/service-request contracts + 3 OpenAPI specs — define the
process manager's interaction for third-party activities and service requests.

------------------------------------------------------------------------
B10.5 wonen-fpx/fpx-pvc-managing-service  (5.2 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-pvc-managing-service
Lifecycle stage: PVC managing (Process Validation & Control).
Authoritative source: yes (1 Flyway migration — Oracle migration base).

------------------------------------------------------------------------
B10.6 wonen-fpx/fpx-crf-integration-service  (6.7 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-crf-integration-service
Lifecycle stage: CRF integration (process integration with mortgage application channel).
Authoritative source: yes (8 Flyway migrations).

Key schemas:
  /src/main/resources/db/migration/
    V1__init.sql, V3__addMortgageApplicationChannelCode.sql
    (mortgage application channel tracking + ShedLock)

------------------------------------------------------------------------
B10.7 wonen-fpx/fpx-med-dynamic-form-service  (see B1.9 — NEW)
------------------------------------------------------------------------
The dynamic form engine encodes form/question/category state — usable as
a template for agentic intake/questionnaire scenarios.

========================================================================
SECTION C — Adjacent repos (supporting infrastructure & data)
========================================================================

These repos are not mortgage-specific but provide data pipelines, reference
data, or infrastructure that feeds mortgage scenarios.

------------------------------------------------------------------------
C1. wonen-fpx/fpx-reference-constant-service  (36.3 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-reference-constant-service
Lifecycle stage: reference constants (shared reference data — rates, limits, norms).

------------------------------------------------------------------------
C2. wonen-fpx/fpx-mca-customer-documents-gateway  (1.7 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-customer-documents-gateway
Lifecycle stage: customer documents gateway (API gateway for document services).

------------------------------------------------------------------------
C3. wonen-fpx/fpx-construction-deposit  (5.3 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-construction-deposit
Lifecycle stage: construction deposit core (bouwdepot — drawdown management).

------------------------------------------------------------------------
C4. wonen-fpx/fpx-bepaal-je-bod  (4.0 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-bepaal-je-bod
Lifecycle stage: "Determine your bid" (customer-facing property valuation tool).

------------------------------------------------------------------------
C5. wonen-fpx/fpx-mca-gateway / fpx-mca-employee-gateway  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-gateway  (2.6 MB)
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-employee-gateway  (3.7 MB)
Lifecycle stage: API gateways (customer + employee facing BFF routers).

------------------------------------------------------------------------
C6. wonen-fpx/fpx-pfa-gui  (19.7 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-pfa-gui
Lifecycle stage: PFA GUI (frontend for Process & Financial Assessment).

------------------------------------------------------------------------
C7. wonen-fpxsu/fpx-structurizr  (0.2 MB)  NEW
------------------------------------------------------------------------
URL: https://dev.azure.com/raboweb/wonen-fpxsu/_git/fpx-structurizr
Lifecycle stage: C4 architecture diagrams (Structurizr DSL -> PlantUML).

------------------------------------------------------------------------
C8. wonen-fpx/fpx-mca-customer-documents-gateway (see C2)
------------------------------------------------------------------------

========================================================================
SUMMARY: PRIORITY COVERAGE MATRIX (updated)
========================================================================

| Priority | Domain | Best repo(s) | Coverage | Reuse |
|----------|--------|-------------|----------|-------|
| 1 | Application/origination | B1.1 dossier-compiling, B1.2 saga, B1.3 overview, B1.5 mortgage-dossier-sync, B1.7 sales, B1.8 employee-appointment, B1.9 med-dynamic-form, B1.10 execution-only, B1.11 financing-plan | FULL | High |
| 2 | Affordability/income | B2.1 bwf-calculations, B2.2 bwf-service (XSD), B2.5 cag-financial-positioning, B2.8 bwf-acceptance-data (OpenAPI) | FULL | High |
| 3 | Underwriting/credit | B3.1 ric-service, B3.2 checksmate-CKI, B3.3 underwriting-engine, B3.5 muh-acceptance, B3.8 knowledge-experience-check | FULL | High |
| 4 | Evidence/documents | B4.1 documentlist, B4.2 validation-documents, B4.3 upload, B4.5 document-dossier-management (23 SQL), B4.6 document-handling (XSD), B4.7 dhc-generating (21 XSD), B4.9 document-engine, B4.11 ics-dossier (65 SQL) | FULL | High |
| 5 | Advice/offer/pricing | B5.1 mirc-tariff-definition, B5.4 mortgage-interest-service, B5.5 premium-indication | FULL | High |
| 6 | Property/valuation | B1.1 (ERD), B6.2 valuationmanagement-api (13 SQL), B6.3 current-house-service | FULL | High |
| 7 | Compliance/identity | B7.1 onboarding-individuals, B7.2 onboarding-orgs, B3.8 knowledge-experience-check, B7.5 risk-shield-scanner, kyca-* | HIGH | Medium |
| 8 | Completion/funding | B8.1 financing-mediation (HDN XSD), B8.3 fmf-disburse, B8.4 fmp-provisioning, B8.5 rfh-reconciling (HTC XSD), A3 mps-htc-scf | FULL | High |
| 9 | Post-completion servicing | B9.1 mca-operations, B9.2 ics-statement, B9.7 forbearance, B9.8 achterstand, B9.10 mtp-process-manager | MEDIUM | Medium |
| 10 | Workflow/audit | B1.2 saga-service, B10.2 construction-deposit-workflow, B10.4 mtp-process-manager (11 XSD), B10.5 pvc-managing | FULL | High |

========================================================================
TOP REPOS TO CLONE FOR SYNTHETIC DATABASE (updated)
========================================================================

To build an artificial mortgage database for agentic experiments, clone in
this priority order:

1. wonen-fpx/fpx-mca-dossier-compiling-service
   -> 48 PlantUML ERD files defining the complete application domain model
   -> documentation/modules/ROOT/pages/05_building_block_view/domain/

2. wonen-fpx/fpx-bwf-calculations
   -> affordability/income calculation engine (InkomstenBerekening, income types)

3. wonen-fpx/fpx-bwf-service
   -> Interest Offer V7 XSD contracts + contract-model module

4. wonen-fpx/fpx-ric-service
   -> mortgage process orchestration API (decision, opportunity, checks, quote)

5. wonen-fpx/fpx-mca-saga-service
   -> dossier/process state machine + Flyway DDL

6. CJIP/checksmate-CKI
   -> BKR/CKI XSD contracts (credit-bureau inquiry schemas)

7. wonen-fpx/fpx-mca-documentlist-service
   -> document checklist + applicant + validation DTOs

8. wonen-fpx/fpx-mca-document-dossier-management-service
   -> 23 Flyway migrations — document + evidence dossier lifecycle

9. wonen-fpx/fpx-financing-mediation-service
   -> HDN v2.5/v2.6 XSD message contracts (Dutch mortgage interchange standard)

10. wonen-fpx/fpx-dhc-generating-service
    -> 21 XSD contracts for mortgage document types (ESIS, application, guarantee)

11. wonen-fpx/fpx-mirc-tariff-definition
    -> tariff/pricing model (interest benchmarks, mortgage loan/condition types)

12. LCA/loancontractextension-api
    -> Flyway SQL DDL (22 migrations) for loan-contract tables

13. LCA/valuationmanagement-api
    -> 13 Flyway migrations — valuation_object_extension + valuation_details DDL

14. LCA/red-management-api
    -> 87 Flyway migrations + CreateFinancialDossier_v4.xsd (financial dossier)

15. wonen-fpx/fpx-pfa-service
    -> 13 OpenAPI contracts — customer financial assessment + household + ID docs

16. wonen-fpx/fpx-bwf-acceptance-data-home-financing-service
    -> OpenAPI: acceptatiegegevens_woningfinanciering_v1.yml

17. wonen-fpx/fpx-mca-execution-only-service
    -> 32 Flyway migrations — eligibility/BFS/dropout for non-advised path

18. wonen-fpx/fpx-cag-financial-positioning-service
    -> existing arrangements / consumptive finance / capital insurance models

19. wonen-fpx/fpx-mca-knowledge-experience-check-service
    -> 19 Flyway migrations — suitability exam lifecycle + dossier link

20. wonen-fpx/fpx-ics-dossier-service
    -> 65 Flyway migrations — insurance dossier lifecycle

Clone command (HTTPS, needs PAT or the authenticated browser session):
  git clone https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-mca-dossier-compiling-service
  git clone https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-bwf-calculations
  git clone https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-bwf-service
  git clone https://dev.azure.com/raboweb/wonen-fpx/_git/fpx-ric-service
  ... (see URLs above)

To generate a PAT: in the authenticated Chrome on port 9222, navigate to
  https://dev.azure.com/raboweb/_usersSettings/tokens

========================================================================
APPENDIX: Complete repo inventory by project
========================================================================

Verified repo counts (from Azure DevOps REST API, Sep 2 2026):
  wonen-fpx:              170 repos (145 non-disabled)
  wonen-fpxsu:             82 repos (69 non-disabled)
  LCA:                    132 repos (124 non-disabled)
  CJIP:                   766 repos (non-disabled activities in onboarding/muh/orv)
  Tribe Housing:           35 repos
  ContentRecognition:      79 repos
  Operations en Ketens
    Support Financieren:   70 repos
  Enterprise Data Lake
    - Airflow:            843 repos

Total across organization: 11,989 repos in 159 projects.

========================================================================
VERIFICATION LOG
========================================================================

All 42 repos from the previous (Aug 27) report verified present in the
current Azure DevOps REST API listing (Sep 2 2026). No repos have been
deleted or renamed. The 10 repos initially flagged as "NOT FOUND" were
artifacts of URL-encoded project name matching (spaces encoded as %20 in
URLs vs literal spaces in the API response) — all resolve correctly via
the dev.azure.com web UI and the REST API.

New repos discovered this refresh: 118 non-infra repos in the wonen-fpx
project alone (94 in wonen-fpx + 24 spanning LCA and other projects) that
were absent from the Aug 27 report. The 38 repos inspected above (with
file-tree analysis) represent the most domain-relevant new finds.

Total artifacts catalogued:
  Flyway SQL migration files (DDL): discovered in 18 repos
  XSD/WSDL contract files:           discovered in 8 repos
  OpenAPI/Swagger specs:              discovered in 3 repos
  PlantUML ERDs:                      48 files in dossier-compiling-service +
                                      3 C4 diagrams in dhc-managing-service
  JPA entities:                       in loancontractextension, valuation-mgmt,
                                      red-management, saga-service
