# Missing Mortgage Domain Pieces — Repository Search Brief

## Objective

Find repositories, modules, schemas, API contracts, events, database models, fixtures, or documentation that cover mortgage lifecycle concepts not represented—or represented only partially—in `mps-common`.

`mps-common` primarily covers mortgage offer/deed execution, agreement administration, collateral/security registration, settlement, and document generation. Treat it as the known baseline described in `mortgage_processes.md`.

The main search target is the **pre-execution mortgage application and underwriting lifecycle**. Secondary targets are **post-completion servicing** and adjacent operational domains.

## Priority 1: Mortgage application and origination

Look for a first-class mortgage application or case aggregate and its lifecycle.

### Missing concepts

- Application, request, or case identifier
- Application version and submission timestamp
- Applicant, co-applicant, household, and party roles
- Application status and status history
- Draft, submitted, in-review, conditionally approved, approved, rejected, withdrawn, expired, and completed states
- Requested mortgage amount, purpose, product preference, and desired term
- Purchase, refinance, remortgage, construction, renovation, and equity-release purposes
- Property purchase price and own-funds contribution
- Consent, declarations, signatures, and terms acceptance
- Channel, intermediary, advisor, branch, and application source
- Required actions, outstanding conditions, and case-owner assignment

### Search terms

English:

- `mortgage application`, `loan application`, `credit application`
- `origination`, `application intake`, `case`, `dossier`
- `applicant`, `co-applicant`, `borrower`, `co-borrower`, `party role`
- `application status`, `submission`, `withdrawal`, `conditional approval`
- `purchase price`, `own funds`, `equity contribution`, `loan purpose`

Dutch and likely abbreviations:

- `hypotheekaanvraag`, `aanvraag`, `aanvraagnummer`, `aanvraagstatus`
- `hypotheekdossier`, `dossier`, `dossiernummer`
- `aanvrager`, `medeaanvrager`, `schuldenaar`, `debiteur`
- `indienen`, `ingediend`, `intrekken`, `ingetrokken`
- `voorlopig akkoord`, `voorwaardelijk akkoord`, `afwijzing`
- `aankoop`, `oversluiten`, `verbouwing`, `eigen middelen`
- `acceptatie`, `hypotheekacceptatie`, `offerteaanvraag`

## Priority 2: Applicant financial position and affordability

Look for normalized applicant income, employment, liabilities, expenses, assets, and affordability calculations.

### Missing concepts

- Employment status, employer, occupation, and employment start date
- Permanent, temporary, flexible, self-employed, pension, and benefit income
- Gross and net salary, holiday allowance, bonuses, commissions, and overtime
- Partner, rental, investment, pension, and other income
- Income verification source, period, confidence, and freshness
- Self-employed company, annual accounts, taxable profit, and assessed sustainable income
- Household composition and dependants
- Recurring household expenses and financial commitments
- Existing debts, revolving credit, student debt, alimony, lease, and credit limits
- Savings, investments, gifts, own funds, and other assets
- Loan-to-income, debt-to-income, loan-to-value, disposable-income, and stress-test calculations
- Maximum borrowing capacity and affordability outcome
- Calculation inputs, ruleset/version, assumptions, and explanation

### Search terms

English:

- `affordability`, `borrowing capacity`, `maximum mortgage`
- `income assessment`, `income verification`, `sustainable income`
- `employment`, `employer`, `salary`, `self-employed`, `annual accounts`
- `household expenditure`, `financial commitments`, `liabilities`
- `debt to income`, `loan to income`, `loan to value`, `LTI`, `DTI`, `LTV`
- `student loan`, `alimony`, `revolving credit`, `credit limit`

Dutch:

- `betaalbaarheid`, `leencapaciteit`, `maximale hypotheek`
- `inkomen`, `toetsinkomen`, `bestendig inkomen`, `inkomensverklaring`
- `werkgever`, `dienstverband`, `arbeidscontract`, `salaris`
- `zelfstandige`, `ondernemer`, `jaarrekening`, `toetsinkomen ondernemer`
- `huishouden`, `huishoudlasten`, `kinderen`, `afhankelijke`
- `verplichtingen`, `schulden`, `doorlopend krediet`, `studieschuld`
- `alimentatie`, `private lease`, `eigen middelen`, `spaargeld`
- `woonquote`, `financieringslast`, `leennorm`, `LTV`, `LTI`

## Priority 3: Underwriting, credit risk, and acceptance

Look for policy evaluation, risk assessment, decisioning, exception handling, and approval conditions.

### Missing concepts

- Credit bureau inquiry and result
- Payment history, arrears, defaults, fraud, and adverse-credit indicators
- Automated and manual underwriting
- Eligibility and policy-rule evaluation
- Risk score, rating, risk class, and probability of default
- Accept, refer, conditionally accept, reject, and cancel decisions
- Decision reason codes and human-readable explanations
- Approval conditions, stipulations, and evidence required before completion
- Policy exceptions, overrides, escalation, and dual approval
- Underwriter assignment, review notes, and audit trail
- Decision model/ruleset version and effective date
- Fairness, explainability, and adverse-action notification

### Search terms

English:

- `underwriting`, `credit decision`, `decisioning`, `acceptance`
- `eligibility`, `policy rule`, `business rule`, `decision table`
- `credit bureau`, `credit check`, `credit score`, `risk score`
- `accept`, `decline`, `reject`, `refer`, `manual review`
- `condition`, `stipulation`, `exception`, `override`, `escalation`
- `adverse action`, `decision reason`, `explanation`

Dutch and domain-specific:

- `kredietbeoordeling`, `acceptatie`, `acceptatiebeleid`
- `krediettoets`, `kredietscore`, `risicoklasse`
- `BKR`, `BKR-toets`, `CKI`, `kredietregistratie`
- `goedkeuren`, `afwijzen`, `doorverwijzen`, `handmatige beoordeling`
- `acceptatievoorwaarde`, `opschortende voorwaarde`
- `uitzondering`, `overrule`, `fiattering`, `vierogenprincipe`
- `reden afwijzing`, `reden code`, `beslisregel`

## Priority 4: Evidence and document collection

Look for document requirements, uploads, extraction, verification, and checklist completion—not only final PDF generation.

### Missing concepts

- Required-document checklist per applicant and application type
- Payslip, employer statement, bank statement, tax return, annual accounts, identity document, purchase agreement, and valuation report
- Upload metadata, document owner, category, version, and retention status
- OCR or structured extraction results
- Field-level provenance, confidence, and manual corrections
- Authenticity, expiry, completeness, consistency, and tampering checks
- Verification status and reviewer comments
- Missing-document requests and reminders
- Document-to-application reconciliation
- Privacy classification, retention, and deletion

### Search terms

English:

- `document checklist`, `required documents`, `evidence`
- `upload`, `attachment`, `document metadata`, `document type`
- `payslip`, `employer statement`, `bank statement`, `tax return`
- `identity verification`, `OCR`, `extraction`, `classification`
- `document verification`, `authenticity`, `tampering`, `expiry`
- `missing document`, `request documents`, `reminder`

Dutch:

- `documentenlijst`, `benodigde documenten`, `bewijsstuk`
- `upload`, `bijlage`, `documentsoort`, `documenttype`
- `loonstrook`, `werkgeversverklaring`, `bankafschrift`
- `belastingaangifte`, `jaaropgave`, `jaarrekening`
- `identiteitsbewijs`, `koopovereenkomst`, `taxatierapport`
- `documentcontrole`, `volledigheid`, `geldigheid`, `verificatie`
- `ontbrekend document`, `document opvragen`

## Priority 5: Advice, product selection, pricing, and offer creation

`mps-common` contains references to advice versions, quotation dates, interest rates, and products, but not a complete advice or offer-composition lifecycle. Search for the upstream source of those values.

### Missing or incomplete concepts

- Customer goals, preferences, knowledge, experience, and risk appetite
- Suitability assessment and advice rationale
- Product catalogue, eligibility, comparison, and recommendation
- Mortgage composition into loan parts
- Repayment strategy and term selection
- Interest-rate quote, pricing adjustments, discounts, and validity period
- Scenario comparison and what-if calculations
- Advice report, advisor recommendation, and customer acceptance
- Offer generation, offer version, expiry, acceptance, and rejection
- Binding versus non-binding offer status

### Search terms

English:

- `mortgage advice`, `suitability`, `recommendation`, `advice report`
- `product selection`, `product catalogue`, `loan part`
- `pricing`, `rate quote`, `discount`, `offer`, `offer expiry`
- `scenario comparison`, `what-if`, `repayment strategy`

Dutch:

- `hypotheekadvies`, `advies`, `adviesrapport`, `adviesmotivatie`
- `passend advies`, `klantdoel`, `risicobereidheid`
- `productselectie`, `productvergelijking`, `leningdeel`
- `renteaanbod`, `rentekorting`, `tarief`, `offerte`
- `offertedatum`, `offertegeldigheid`, `offerte accepteren`
- `bindend aanbod`, `rentevoorstel`, `scenariovergelijking`

## Priority 6: Property acquisition and valuation workflow

`mps-common` contains final registered-property and valuation data. Search for the workflow that creates and verifies those records.

### Missing or incomplete concepts

- Property search and property-source integration
- Purchase agreement and purchase conditions
- Seller, buyer, estate agent, and conveyancer roles
- Appraisal order, appointment, status, and provider assignment
- Valuation report ingestion and validation
- Automated valuation model and confidence interval
- Property eligibility, condition, defects, and sustainability improvements
- New-build project, construction milestones, and drawdown plan
- Title, ownership, encumbrance, and land-registry checks before execution
- Collateral acceptance decision

### Search terms

English:

- `property acquisition`, `purchase agreement`, `sale contract`
- `appraisal order`, `valuation workflow`, `valuation report`, `AVM`
- `property eligibility`, `collateral acceptance`, `title search`
- `new build`, `construction milestone`, `drawdown`

Dutch:

- `koopakte`, `koopovereenkomst`, `ontbindende voorwaarden`
- `taxatieopdracht`, `taxatieproces`, `taxatierapport`, `modelwaarde`
- `onderpandacceptatie`, `objectacceptatie`
- `kadaster`, `eigendomscontrole`, `beslag`, `erfdienstbaarheid`
- `nieuwbouw`, `bouwdepot`, `bouwtermijn`, `meerwerk`

## Priority 7: Compliance, identity, fraud, and financial crime

Look for checks attached to applicants, counterparties, accounts, source of funds, and transactions.

### Missing concepts

- Identity verification and identity-document validation
- Customer due diligence and beneficial ownership
- Sanctions, PEP, watchlist, and adverse-media screening
- Fraud indicators, device risk, impersonation, and document fraud
- Source of funds and source of wealth
- AML risk assessment and enhanced due diligence
- Suspicious-activity review and case escalation
- Bank-account ownership verification
- Consent and GDPR/legal-basis records

### Search terms

English:

- `KYC`, `CDD`, `AML`, `identity verification`
- `sanctions`, `PEP`, `watchlist`, `adverse media`
- `fraud`, `impersonation`, `document fraud`, `device risk`
- `source of funds`, `source of wealth`, `account verification`
- `beneficial owner`, `UBO`, `enhanced due diligence`

Dutch:

- `klantonderzoek`, `identificatie`, `identiteitscontrole`
- `Wwft`, `sanctielijst`, `PEP`, `UBO`
- `fraude`, `documentfraude`, `rekeningverificatie`
- `herkomst middelen`, `bron van vermogen`
- `verscherpt klantonderzoek`, `ongebruikelijke transactie`

## Priority 8: Completion, funding, and disbursement

`mps-common` contains notary and settlement fields, but search for the orchestration and accounting surrounding actual completion.

### Missing or incomplete concepts

- Completion readiness and pre-completion conditions
- Funding instruction and funding authorization
- Loan booking and account activation
- Settlement breakdown and reconciliation
- Transfer to notary and payment confirmation
- Repayment of prior lenders and discharge confirmation
- Construction-depot funding and drawdown transactions
- Failed, reversed, duplicated, or partially completed payments
- General-ledger and accounting postings
- Completion confirmation and handoff to servicing

### Search terms

English:

- `completion`, `closing`, `funding`, `disbursement`
- `settlement`, `reconciliation`, `payment instruction`
- `loan booking`, `account activation`, `servicing handoff`
- `redemption`, `lien release`, `discharge`

Dutch:

- `passeren`, `passeerdatum`, `aktepassering`
- `uitbetaling`, `gelden vrijgeven`, `betaalinstructie`
- `afrekening`, `sluitnota`, `notarisbetaling`
- `aflossen`, `royement`, `doorhaling hypotheek`
- `lening activeren`, `overdracht beheer`

## Priority 9: Post-completion mortgage servicing

Look for ongoing customer and account servicing after the deed has been executed.

### Missing concepts

- Payment transactions and amortization ledger
- Direct-debit mandates and payment allocation
- Annual statements and tax statements
- Interest-rate reset, renewal, and customer notification
- Extra repayment, early redemption, and penalty calculation
- Arrears, delinquency, collections, forbearance, and payment arrangements
- Term extension, repayment-method change, and contract modification
- Customer address, bank account, borrower, and ownership changes
- Complaints, service requests, and correspondence
- Maturity, redemption statement, discharge, and account closure

### Search terms

English:

- `mortgage servicing`, `loan servicing`, `account servicing`
- `payment transaction`, `amortization`, `direct debit`
- `rate reset`, `renewal`, `early repayment`, `prepayment penalty`
- `arrears`, `delinquency`, `collections`, `forbearance`
- `contract modification`, `redemption statement`, `account closure`

Dutch:

- `hypotheekbeheer`, `leningbeheer`, `contractbeheer`
- `incasso`, `termijnbetaling`, `aflossingsschema`
- `renteherziening`, `renteverlenging`, `extra aflossen`
- `boeterente`, `vergoedingsrente`, `achterstand`
- `bijzonder beheer`, `betalingsregeling`, `hypotheek wijzigen`
- `aflosnota`, `jaaropgave`, `royement`, `rekening sluiten`

## Priority 10: Cross-cutting workflow and agentic-scenario structures

These structures are especially valuable for synthetic agentic scenarios because they encode process state, actions, evidence, and failures.

### Missing concepts

- Workflow/process instance and task identifiers
- State transitions and transition guards
- Human task assignment, queue, priority, and due date
- Required action, recommendation, approval, and rejection
- SLA, timeout, reminder, escalation, and retry
- Validation findings and remediation actions
- Business and technical error taxonomies
- Audit events, actor identity, timestamps, and before/after values
- Correlation, causation, trace, and idempotency identifiers
- External-service request/response envelopes
- Manual override and four-eyes approval
- Notification preferences, delivery attempts, and acknowledgements

### Search terms

- `workflow`, `process`, `state machine`, `status transition`
- `task`, `work item`, `case management`, `assignment`, `queue`
- `SLA`, `deadline`, `timeout`, `retry`, `escalation`
- `validation finding`, `remediation`, `required action`
- `audit event`, `event history`, `before`, `after`, `mutation`
- `correlationId`, `causationId`, `traceId`, `idempotencyKey`
- `manual override`, `dual approval`, `four eyes`, `vierogenprincipe`

## Likely artifact types and locations

Search more broadly than Java DTO class names. Useful schemas may live in:

- Java/Kotlin records, entities, DTOs, value objects, and enums
- OpenAPI/Swagger specifications
- AsyncAPI specifications and event schemas
- Avro, Protobuf, JSON Schema, and XSD files
- Database migrations, DDL, ORM entities, and canonical data models
- GraphQL schemas
- API gateway definitions
- BPMN/DMN workflow and decision models
- Drools or other business-rule files
- Test fixtures, WireMock mappings, Postman collections, and contract tests
- Data dictionaries, architecture decision records, and domain documentation
- Generated clients whose source contract is in another repository
- Kafka topic/message definitions
- Analytics models only when they preserve operational domain semantics

Useful filename and directory patterns include:

- `*application*`, `*origination*`, `*underwriting*`, `*acceptance*`
- `*affordability*`, `*income*`, `*employment*`, `*liability*`
- `*document*`, `*evidence*`, `*verification*`
- `*mortgage*`, `*hypotheek*`, `*loan*`, `*credit*`, `*krediet*`
- `*dossier*`, `*case*`, `*workflow*`, `*decision*`
- `openapi*`, `swagger*`, `asyncapi*`, `*.avsc`, `*.proto`, `*.xsd`
- `db/migration`, `schema`, `contracts`, `events`, `fixtures`, `mappings`

## False positives and interpretation guidance

Do not report a repository as covering a domain solely because a keyword appears.

- `application` may mean a software application rather than a mortgage application.
- `mortgage` may refer only to configuration, routing, or UI labels.
- `client` may mean an HTTP client rather than a customer.
- `income` may be a reporting metric rather than applicant income.
- `decision` may be a technical routing decision rather than underwriting.
- `document` may mean generated correspondence rather than applicant evidence.
- `security` may mean cybersecurity rather than mortgage collateral.
- `collateral` may refer to marketing material rather than secured property.
- `offer` may refer to a product catalogue entry rather than a customer-specific binding offer.

Prefer artifacts that expose several related fields, relationships, statuses, validations, API operations, fixtures, or persistence mappings. Trace generated classes back to their authoritative contract where possible.

## Evidence required from the search agent

For every candidate repository or module, return:

1. Repository and module name.
2. Exact file paths and relevant symbols.
3. Domain category from this document.
4. Lifecycle stage covered.
5. Representative fields, states, relationships, or operations.
6. Evidence that the structure is operational—not merely a label or reporting projection.
7. Whether the source is authoritative, generated, mapped, or duplicated.
8. Data sensitivity: PII, financial, credit, identity, account, or property data.
9. Reuse suitability for synthetic generation:
   - `high`: cohesive schema with constraints and relationships;
   - `medium`: useful partial structure requiring composition;
   - `low`: flattened view, report, or weakly typed payload.
10. Gaps that remain after including the candidate.

## Suggested result matrix

| Repository/module | Domain category | Lifecycle stage | Key schemas/symbols | Authoritative source | Synthetic reuse | Sensitive fields | Remaining gaps |
|---|---|---|---|---|---|---|---|
| Example | Affordability | Application assessment | `Income`, `Employment`, `AffordabilityResult` | OpenAPI contract | High | Income, employer | Self-employed income missing |

## Completion criteria

The search is complete when it either finds credible schemas or explicitly records no evidence for each of these minimum categories:

- application/case aggregate;
- applicant and household parties;
- employment and income;
- expenses, liabilities, and assets;
- affordability calculation;
- credit bureau and underwriting decision;
- conditions and exception handling;
- evidence/document collection;
- advice/product/offer composition;
- property acquisition and valuation workflow;
- identity, fraud, and compliance checks;
- completion/funding orchestration;
- post-completion servicing;
- workflow, audit, and event metadata.

